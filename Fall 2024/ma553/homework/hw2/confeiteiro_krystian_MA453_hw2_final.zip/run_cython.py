import heat2d

if __name__ == '__main__':
    heat2d.main()
