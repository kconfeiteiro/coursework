#!/bin/sh
qsub -I -l nodes=1:ppn=16 -l walltime=00:30:00
