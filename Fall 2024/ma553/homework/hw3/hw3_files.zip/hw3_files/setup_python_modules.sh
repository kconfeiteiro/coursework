#!/bin/sh

pip install --upgrade --user numpy cython mpi4py numba numexpr matplotlib scipy cffi 
