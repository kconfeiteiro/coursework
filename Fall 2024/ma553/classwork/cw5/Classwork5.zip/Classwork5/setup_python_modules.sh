#!/bin/sh

pip3 install --upgrade --proxy http://dbproxy.erau.edu:3128/ --user numpy cython mpi4py numba numexpr matplotlib scipy cffi 
