%% Hangman Script
% Created by Aidan Mackey
% Grand Canyon University

clear    % Resets command window and workspace
clc

fprintf('Initiating hangman puzzle...\n');

f2 = figure;
h = [0 10];                                             % Builds a figure to "draw" puzzle
k = [0 0];
l = [10 10];
S1 = line (h,k); S1.Color = 'k'; S1.LineWidth = 3;      % The puzzle is 10x10 with thick borders
S2 = line (k,h); S2.Color = 'k'; S2.LineWidth = 3;
S3 = line (h,l); S3.Color = 'k'; S3.LineWidth = 3;
S4 = line (l,h); S4.Color = 'k'; S4.LineWidth = 3;

noose_a = line([8 8],[8 0]); noose_a.Color = 'k'; noose_a.LineWidth = 3;     % Draws the gallow to "hang" the person
noose_b = line([5.5 8],[8 8]); noose_b.Color = 'k'; noose_b.LineWidth = 3;   % This code sounds depressing
noose_c = line([5.5 5.5],[6 8]); noose_c.Color = 'k'; noose_c.LineWidth = 3;

Used_Letters = [];

Player = input('Would you like to play with the computer or against another player?\nReply "computer" for computer, and reply "player" for player: ','s');
Var_int = length(Player); % Uses the length of the response from the user to determine the game mode type

if Var_int == 8
Puzzle_1 = 'My milkshake brings all the boys to the yard';  % Song by Kellis
Puzzle_2 = 'Full send boys?';                               % Battlecry of teenage boys everywhere
Puzzle_3 = 'My head is swirling with all the activities';   % Step Brothers
Puzzle_4 = 'Shes your friend, Ralph';                       % So I married an axe murderer
Puzzle_5 = 'Holy shnikies';                                 % Tommy Boy
Puzzle_6 = 'Youre killing me smalls';                       % The sandlot
Puzzle_7 = 'I wake up in the morning and piss excellence';  % Talledaga Nights
Puzzle_8 = 'Tina eat your food you fat lard';               % Napoleon Dynamite
Puzzle_9 = 'Sphinx of black quartz, judge my vow';          % A pangram

a = randi(9);

if a == 1                     % Code to randomly select one of the above puzzles
    Var_11 = Puzzle_1;
elseif a == 2
    Var_11 = Puzzle_2;
elseif a == 3
    Var_11 = Puzzle_3;
elseif a == 4
    Var_11 = Puzzle_4;
elseif a == 5
    Var_11 = Puzzle_5;
elseif a == 6
    Var_11 = Puzzle_6;
elseif a == 7
    Var_11 = Puzzle_7;
elseif a == 8
    Var_11 = Puzzle_8;
elseif a == 9
    Var_11 = Puzzle_9;
end

clc

elseif Var_int == 6
    clc
    Var_11 = input('Enter a puzzle for your friend to solve: \n','s'); % Allows the user to make their own puzzle for a friend to solve
    clc
else
    fprintf('Error: Please enter a valid response next time\n'); % Catch for user error in game mode
    return
end

Var_1 = lower(Var_11);       % Turns the puzzle into all lower case so it is easier to work with
str_A = string(Var_1);       % Turns the puzzle into a string to be worked with
counter = 0;                 % Counter for counting missed letters

Var_5 = length(Var_1);       % Gets length of puzzle

cc = isspace(Var_1);         % Determines where the spaces between the words are
ccc = isletter(Var_1);

for ii = 1:Var_5
    if cc(ii) == 1                                    % Forms the puzzle to be displayed and inputs it into a variable
        Var_9(ii) = ' '; Var_12(ii) = ' ';            % Spaces are filled in first
    elseif ccc(ii) == 0
        Var_9(ii) = Var_1(ii); Var_12(ii) = Var_1(ii); % Punctuation marks are filled in leaving only letters
    else
        Var_9(ii) = '-'; Var_12(ii) = '-';             % Every spot with a letter is marked with a dash
    end
    
end

fprintf('%s \n',Var_12)           % Prints the puzzle ready to be guessed 

while 1
    fprintf('Wrong Letters: [%s]\n',Used_Letters);         % Displays used letters with every loop
    c = isletter(Var_9);                                   % As letters are inputed into the puzzle,
    d = sum(c); dd = sum(cc); ddd = Var_5 - (sum(ccc)+dd); % this counts the amount of letters, spaces 
    e = d + dd + ddd;                                      % and punctuation marks previously established
    clear Var_6            % Need to be reset
    clear Var_7            % If there's a value, the code breaks at line 125
    
    if e == Var_5                                          % If this adds up to the total length, the 
        clc                                                % puzzle has been solved, the loop is broken
        fprintf('%s\n',Var_12)                              % and the final puzzle is displayed
        break
    end
    
    str_C = string(Var_9);                                 % Creates a string of our dashed puzzle
    Var_b = input('Guess a letter: ','s');                 % The player gets to guess a letter (Finally)
        test = size(Var_b);                               
        
        if test(2) == Var_5
            Var_14 = lower(Var_b);
            str_E = string(Var_14);
            Var_15 = strfind(str_A, str_E);
            Var_16 = length(Var_15);
            if Var_16 == 1
                clc
                fprintf('You are correct!\n')
                fprintf('"%s"\n',Var_11)
                break
            else 
                 if counter == 0                                                                                    % If the guess is wrong
                man_a = rectangle('Position',[5, 5, 1, 1],'Curvature',[1,1],'FaceColor', 'w','EdgeColor','k'); % the first mistake draws the head
            elseif counter == 1
                man_b = line ([5.5 5.5],[3 5]); man_b.Color = 'k';                                             % The second mistake draws the body
            elseif counter == 2
                man_c = line ([5.5 5],[3 1.5]); man_c.Color = 'k';                                             % The third mistake draws the left leg
            elseif counter == 3
                man_d = line ([5.5 6],[3 1.5]); man_d.Color = 'k';                                             % The fourth mistake draws the right leg
            elseif counter == 4
                man_e = line ([4.75 5.5],[3.5 4.5]); man_e.Color = 'k';                                        % the fifth mistake draws the left arm
            elseif counter == 5
                man_f = line ([5.5 6.25],[4.5 3.5]); man_f.Color = 'k';                                        % The sixth mistake draws the right arm 
                man_g = line ([5.2 5.4],[5.4 5.6]); man_g.Color = 'r';                                         % also adds red "X's" over the eyes
                man_h = line ([5.2 5.4],[5.6 5.4]); man_h.Color = 'r';
                man_i = line ([5.6 5.8],[5.4 5.6]); man_i.Color = 'r';
                man_j = line ([5.6 5.8],[5.6 5.4]); man_j.Color = 'r';
                
                fprintf('You is now dead\n');                                                                  % Gives death message
                fprintf('The correct answer was:\n "%s"\n',str_A);                                             % Displays correct original puzzle
                break                                                                                          % Ends the game by breaking loop
                 end
            clc
            fprintf('That is incorrect\n');                                   % If this wasn't their final mistake
            fprintf('%s\n',Var_12)                                            % Reprints puzzle
            counter = counter + 1;
            continue
            end

        elseif test(2) > 1                                           % First catch to see if user entered one number 
            clc                                                  % If > 1, screen is cleared
            fprintf('Please only enter one letter at a time.\n') % Politely ask them to guess only one letter
            fprintf('%s\n',Var_12)                               % Reprint the puzzle
            continue                                             % Restart loop
        elseif test(2) == 0                                      % If they forget to enter a letter
            clc                                                  % clear screen
            fprintf('Please enter a letter.\n')                  % Politley ask for a letter
            fprintf('%s\n',Var_12)                               % Reprint the puzzle
            continue                                             % Restart loop
        end
        
        Var_10 = isletter(Var_b);                                % Tests to see that a letter is inputted
        if Var_10 == 0                                           % If not
            clc                                                  % clears screen
            fprintf('Please enter an actual letter.\n')          % Politely asks for ACTUAL letter
            fprintf('%s\n',Var_12)                               % Reprint the Puzzle
            continue                                             % Restart loop
        end
        
        Var_13 = lower(Var_b);
        str_B = string(Var_13);   % Once the guess passes all the catches, the 
        clc                      % user input is converted to a string
      
        Var_8 = char(Used_Letters);    % Initializes variable for used letters
        str_D = string(Var_8);         % Converts this variable to a string
        Var_6 = strfind(str_D,str_B);  % Looks to see if user has already guessed
        Var_7 = length(Var_6);         % that letter
        
        if Var_7 >= 1                                                   % If the user has already guessed letter
            fprintf('You already guessed that letter. Try again.\n');   % politely asks for new, unused letter
            fprintf('%s\n',Var_12)                                      % Reprints puzzle
            continue
        end
        
        Var_3 = strfind(str_A, str_B);  % Searches the puzzle for the users guess and saves location in variable
        Var_4 = length(Var_3);          % Gives the number of occurrences of that letter

        for kk = 1:Var_4                   % Fancy little "for" loop to insert the letters 
                Var_9(Var_3(kk)) = Var_b;  % where they go
        end
        
        f = isletter(Var_9);
        
        for ll = 1:Var_5                     % "Var_9" is used for the puzzle to determine
            if f(ll) == 1                    % the letters needed to be guessed. It is a 
                Var_12(ll) = Var_11(ll);     % lower case version of the string used just
                continue                     % to find the letters. "Var_12" takes the letters
            elseif f(ll) == 0                % that are correct in "Var_9" and copies them from
                Var_12(ll) = Var_9(ll);      % Var_11 to display capital letters.
            end
        end

        if Var_4 == 1                                                                 % Displays number of times that
            fprintf('There is 1 occurrence of "%s" in the puzzle.\n',str_B);          % their guess is in the puzzle
            fprintf('%s\n',Var_12)                                                    % I split it up for the sake 
        elseif Var_4 > 1                                                              % of grammar in the fprint 
            fprintf('There are %d occurrences of "%s" in the puzzle.\n',Var_4,str_B); % statement
            fprintf('%s\n',Var_12)                                                    % Displays the puzzle with 
        else                                                                          % newly acquired letters
            if counter == 0                                                                                    % If the guess is wrong
                man_a = rectangle('Position',[5, 5, 1, 1],'Curvature',[1,1],'FaceColor', 'w','EdgeColor','k'); % the first mistake draws the head
            elseif counter == 1
                man_b = line ([5.5 5.5],[3 5]); man_b.Color = 'k';                                             % The second mistake draws the body
            elseif counter == 2
                man_c = line ([5.5 5],[3 1.5]); man_c.Color = 'k';                                             % The third mistake draws the left leg
            elseif counter == 3
                man_d = line ([5.5 6],[3 1.5]); man_d.Color = 'k';                                             % The fourth mistake draws the right leg
            elseif counter == 4
                man_e = line ([4.75 5.5],[3.5 4.5]); man_e.Color = 'k';                                        % the fifth mistake draws the left arm
            elseif counter == 5
                man_f = line ([5.5 6.25],[4.5 3.5]); man_f.Color = 'k';                                        % The sixth mistake draws the right arm 
                man_g = line ([5.2 5.4],[5.4 5.6]); man_g.Color = 'r';                                         % also adds red "X's" over the eyes
                man_h = line ([5.2 5.4],[5.6 5.4]); man_h.Color = 'r';
                man_i = line ([5.6 5.8],[5.4 5.6]); man_i.Color = 'r';
                man_j = line ([5.6 5.8],[5.6 5.4]); man_j.Color = 'r';
                
                fprintf('You is now dead\n');                                                                  % Gives death message
                fprintf('The correct answer was:\n "%s"\n',str_A);                                             % Displays correct original puzzle
                break                                                                                          % Ends the game by breaking loop
            end
            fprintf('There are 0 occurences of "%s" in the puzzle.\n',str_B); % If this wasn't their final mistake
            fprintf('%s\n',Var_12)                                            % Reprints puzzle
            counter = counter + 1;                                            % Adds a number to the counter
            Used_Letters(counter) = Var_b;                                    % Incorrect guess added to list of used letters
        end
        
end