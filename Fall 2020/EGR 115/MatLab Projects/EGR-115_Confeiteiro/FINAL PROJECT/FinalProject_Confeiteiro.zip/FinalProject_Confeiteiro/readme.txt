I have instructions commented in my program but I am writing this to simplify things.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Date: 12/05/20
Time: 10:23 PM

Program name: EGR-115 Final Project - FINAL DRAFT
Program purpose: 
This program is a basic hangman game that I have coded using techniques I have learned this
semester from EGR-115. 

The rules are very simple: Choose to play agianst the computer or against a friend, start 
guessing, if you make an incorrect guess, a piece of the hangman is added and the letter is added to the list of 
incorrect guesses, if you guess correctly, you keep guessing until you get the word right or until you run out of 
of guessing (7 pieces of the hangman figure so there would be 7 guesses).

After you have won or lost, you are prompted
with a choice to play the game again or not, if you type 'no,' you will be prompted with the last message before 
the program ends. 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Created by: Krystian Confeiteiro 
Created on: 10/22/20
Last edited: 12/05/20

From template: 
"By submitting this program with my name, I affirm that the creation and modifications of this program are my 
own work."

