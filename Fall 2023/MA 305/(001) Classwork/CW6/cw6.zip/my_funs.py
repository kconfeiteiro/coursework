import math

def f(x):
    y = (2*x+1)*(x**2+x+1)**3 
    return y

def g(x):
    y = math.exp(-x**2) 
    return y

