import math

def left_sum(f,a,b,n):
    """Approximates integrals by summing the area of the rectangles with height taken from the left end."""
    dx=(b-a)/n
    lsum=0
    for i in range(n):
        xi = a+i*dx
        lsum += f(xi)
    return dx*lsum

def right_sum(f,a,b,n):
    """Approximates integrals by summing the area of rectangles with height taken from the right end."""
    dx=(b-a)/n
    rsum=0
    for i in range(1,n+1):
        xi = a+i*dx
        rsum += f(xi)
    return dx*rsum

def middle_sum(f,a,b,n):
    """Approximates integrals by summing the area of rectangles with height taken from the midpoint, not completed yet."""
    dx=(b-a)/n
    msum=0
    for i in range(n):
        xibar = a+(i+0.5)*dx
        msum += f(xibar)
    return dx*msum

